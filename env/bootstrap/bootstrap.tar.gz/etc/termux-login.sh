##
## This script is sourced by /data/data/com.ce.ide/files/usr/bin/login before executing shell.
##
